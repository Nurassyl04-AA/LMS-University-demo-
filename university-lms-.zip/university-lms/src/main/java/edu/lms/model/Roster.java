package edu.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Roster {
    private final List<Student> students = new ArrayList<>();

    public void addStudent(Student student) {
        students.add(student);
    }

    public List<Student> getStudents() {
        return students;
    }
}
